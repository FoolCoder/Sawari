module.exports={
  assets: ['./app/assets/fonts/']
}