export const link = 'http://3.95.158.224:9999'
// export const link = 'http://0902-101-50-108-76.ngrok.io'

export const filterdadds = '/ad/getFilteredAds'
export const useradds = '/ad/getAdsByUser?userId='
export const postuseradd = '/ad/insertAd'
export const useraddstatues = '/ad/changeSoldStatus?adID='

export const rentfilterdadds = '/rentOut/getFilteredRentOut'
export const rentuseradds = '/rent/getRentByUser?userId='
export const rentpostuseradd = '/rentOut/insertRentOut'

export const apikey = 'AIzaSyA-_ESKOszOV6bSzAqb6frFWMZqnLeQj1U'