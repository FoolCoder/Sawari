const cardetail = 'cardetail'
const socketConnection = 'socketConnection'
const newsFeed = 'newsFeed'
const user = 'user'
const dylink = 'dylink'
const addnotification='addnotification'
const setnotification='setnotification'

export { cardetail, socketConnection, addnotification, setnotification,newsFeed, user, dylink }