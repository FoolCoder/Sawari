const cardetail = 'cardetail'
const socketConnection = 'socketConnection'
const newsFeed = 'newsFeed'
const user = 'user'
const dylink = 'dylink'

export { cardetail, socketConnection, newsFeed, user, dylink }